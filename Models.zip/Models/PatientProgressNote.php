<?php
// PatientProgressNote.php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PatientProgressNote extends Model
{
    use HasFactory;

    protected $primaryKey = 'note_id';

    protected $fillable = [
        'patient_id',
        'nurse_id',
        'appointment_id',
        'note_type',
        'note_content',
        'observation_time',
        'requires_doctor_attention',
        'is_confidential',
    ];

    protected $casts = [
        'observation_time' => 'datetime',
        'requires_doctor_attention' => 'boolean',
        'is_confidential' => 'boolean',
    ];

    public function patient()
    {
        return $this->belongsTo(Patient::class, 'patient_id');
    }

    public function nurse()
    {
        return $this->belongsTo(Nurse::class, 'nurse_id');
    }

    public function appointment()
    {
        return $this->belongsTo(Appointment::class, 'appointment_id');
    }
}