<?php
// MedicationAdministration.php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MedicationAdministration extends Model
{
    use HasFactory;

    protected $primaryKey = 'administration_id';

    protected $fillable = [
        'prescription_item_id',
        'patient_id',
        'nurse_id',
        'administered_at',
        'scheduled_time',
        'status',
        'dosage_given',
        'route',
        'notes',
        'refusal_reason',
    ];

    protected $casts = [
        'administered_at' => 'datetime',
        'scheduled_time' => 'datetime',
    ];

    public function prescriptionItem()
    {
        return $this->belongsTo(PrescriptionItem::class, 'prescription_item_id');
    }

    public function patient()
    {
        return $this->belongsTo(Patient::class, 'patient_id');
    }

    public function nurse()
    {
        return $this->belongsTo(Nurse::class, 'nurse_id');
    }

    // Check if medication was given on time
    public function wasOnTime()
    {
        if (!$this->scheduled_time || !$this->administered_at) {
            return null;
        }

        $diff = $this->scheduled_time->diffInMinutes($this->administered_at, false);
        
        // Consider on-time if within 30 minutes
        return abs($diff) <= 30;
    }
}
