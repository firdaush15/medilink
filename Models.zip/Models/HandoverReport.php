<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HandoverReport extends Model
{
    use HasFactory;

    protected $primaryKey = 'handover_id';

    protected $fillable = [
        'nurse_id',
        'patient_id',
        'handover_to_nurse_id',
        'priority',
        'clinical_summary',
        'medications',
        'pending_tasks',
        'nursing_notes',
        'voice_note_path',
        'handover_time',
        'is_acknowledged',
        'acknowledged_at',
    ];

    protected $casts = [
        'handover_time' => 'datetime',
        'acknowledged_at' => 'datetime',
        'is_acknowledged' => 'boolean',
    ];

    public function nurse()
    {
        return $this->belongsTo(Nurse::class, 'nurse_id');
    }

    public function patient()
    {
        return $this->belongsTo(Patient::class, 'patient_id');
    }

    public function handoverToNurse()
    {
        return $this->belongsTo(Nurse::class, 'handover_to_nurse_id');
    }
}