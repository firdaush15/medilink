<?php
// Migration: create_patient_progress_notes_table.php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('patient_progress_notes', function (Blueprint $table) {
            $table->id('note_id');
            $table->foreignId('patient_id')->constrained('patients', 'patient_id')->onDelete('cascade');
            $table->foreignId('nurse_id')->constrained('nurses', 'nurse_id')->onDelete('cascade');
            $table->foreignId('appointment_id')->nullable()->constrained('appointments', 'appointment_id')->onDelete('set null');
            
            // Note content
            $table->enum('note_type', [
                'General Observation',
                'Pain Assessment',
                'Behavioral Observation',
                'Response to Treatment',
                'Patient Education',
                'Discharge Planning',
                'Other'
            ])->default('General Observation');
            
            $table->text('note_content');
            $table->timestamp('observation_time');
            
            // Important flags
            $table->boolean('requires_doctor_attention')->default(false);
            $table->boolean('is_confidential')->default(false);
            
            $table->timestamps();
            
            // Indexes
            $table->index(['patient_id', 'observation_time']);
            $table->index('requires_doctor_attention');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('patient_progress_notes');
    }
};