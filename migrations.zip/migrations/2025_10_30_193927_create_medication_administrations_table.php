<?php
// Migration: create_medication_administrations_table.php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('medication_administrations', function (Blueprint $table) {
            $table->id('administration_id');
            $table->foreignId('prescription_item_id')->constrained('prescription_items', 'item_id')->onDelete('cascade');
            $table->foreignId('patient_id')->constrained('patients', 'patient_id')->onDelete('cascade');
            $table->foreignId('nurse_id')->constrained('nurses', 'nurse_id')->onDelete('cascade');
            
            // Administration details
            $table->timestamp('administered_at');
            $table->timestamp('scheduled_time')->nullable();
            $table->enum('status', ['Administered', 'Refused', 'Held', 'Missed'])->default('Administered');
            $table->string('dosage_given')->comment('Actual dosage administered');
            $table->enum('route', ['Oral', 'IV', 'IM', 'SC', 'Topical', 'Inhaled', 'Other'])->nullable();
            
            // Documentation
            $table->text('notes')->nullable()->comment('Any observations or patient reactions');
            $table->text('refusal_reason')->nullable()->comment('If patient refused medication');
            
            $table->timestamps();
            
            // Indexes
            $table->index(['patient_id', 'administered_at']);
            $table->index(['nurse_id', 'administered_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('medication_administrations');
    }
};